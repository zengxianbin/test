package com.ghz.testweb;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! i am oldboy22333" );
    }
}
